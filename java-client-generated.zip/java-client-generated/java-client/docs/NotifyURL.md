
# NotifyURL

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



