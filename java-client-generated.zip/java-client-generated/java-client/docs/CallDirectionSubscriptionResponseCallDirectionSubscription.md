
# CallDirectionSubscriptionResponseCallDirectionSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callbackReference** | [**CallbackReferenceResponse**](CallbackReferenceResponse.md) |  | 
**filter** | [**CallEventFilter**](CallEventFilter.md) |  | 
**clientCorrelator** | [**ClientCorrelator**](ClientCorrelator.md) |  | 
**resourceURL** | [**ResourceURL**](ResourceURL.md) |  | 



