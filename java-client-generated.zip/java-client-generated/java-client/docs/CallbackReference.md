
# CallbackReference

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**notifyURL** | **String** | NotifyURL | 



