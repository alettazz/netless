
# AddressDirection

## Enum


* `CALLED` (value: `"Called"`)

* `CALLING` (value: `"Calling"`)



