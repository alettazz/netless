
# CallDirectionSubscription1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callbackReference** | [**CallbackReference1**](CallbackReference1.md) |  |  [optional]
**filter** | [**CallEventFilter1**](CallEventFilter1.md) |  |  [optional]
**clientCorrelator** | **String** | ClientCorrelator | 



