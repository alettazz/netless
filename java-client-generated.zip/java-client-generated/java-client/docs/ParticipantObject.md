
# ParticipantObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**participantAddress** | **String** |  | 



