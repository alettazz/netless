
# CallSessionInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**participant** | [**List&lt;ParticipantObject1&gt;**](ParticipantObject1.md) |  | 



