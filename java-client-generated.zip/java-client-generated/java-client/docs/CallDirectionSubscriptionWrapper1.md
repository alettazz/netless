
# CallDirectionSubscriptionWrapper1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callDirectionSubscription** | [**CallDirectionSubscription1**](CallDirectionSubscription1.md) |  |  [optional]



