
# ClickToCallResponse1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**caller** | **String** |  | 
**callee** | **String** |  | 



