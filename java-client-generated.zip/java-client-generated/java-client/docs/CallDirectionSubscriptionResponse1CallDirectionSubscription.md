
# CallDirectionSubscriptionResponse1CallDirectionSubscription

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callbackReference** | [**CallbackReferenceResponse1**](CallbackReferenceResponse1.md) |  |  [optional]
**filter** | [**CallEventFilter1**](CallEventFilter1.md) |  |  [optional]
**clientCorrelator** | **String** | ClientCorrelator | 
**resourceURL** | **String** | ResourceURL | 



