
# CallDirectionSubscriptionResponse1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**callDirectionSubscription** | [**CallDirectionSubscriptionResponse1CallDirectionSubscription**](CallDirectionSubscriptionResponse1CallDirectionSubscription.md) |  |  [optional]



