
# CallbackReferenceResponse1

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**notifyURL** | **String** | NotifyURL | 
**notificationFormat** | **String** |  | 



